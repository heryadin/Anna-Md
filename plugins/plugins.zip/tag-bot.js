import fs from 'fs'

let handler  = async (m, { conn }) => {
let tag = fs.readFileSync('./sticker/tagbot.webp')
conn.sendFile(m.chat, tag, '', '', m)
}
handler.customPrefix = /^(@6282181240183|@anna|anna|annabot|anna bot|anna botz|woi|halo|hallo|test|tes|p|cok)$/i
handler.command = new RegExp

export default handler