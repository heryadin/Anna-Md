import axios from 'axios'
let handler = async(m, { conn, text }) => {
	let text = '```Hai kak untuk menggunakan free trial silahkan ketik *.join (linkgc)*```'
    conn.reply(m.chat, hasil, m)
	}
handler.command = /^(trialjoin)$/i
export default handler