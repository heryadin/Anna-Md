import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
let res = await fetch('https://raw.githubusercontent.com/heryadin/Api/main/anime/simpown.json')
if (!res.ok) throw await `${res.status} ${res.statusText}`;
let json = await res.json();
let url = json[Math.floor(Math.random() * json.length)]
conn.sendButton(m.chat, 'Cuman Simpenan Owner Kok Kak><', wm, url, [['NEXT','.simpown']],m)
}
handler.command = /^(simpown)$/i
handler.tags = ['anime']
handler.help = ['simpown']
export default handler
handler.limit = true