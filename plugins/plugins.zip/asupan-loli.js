import fetch from 'node-fetch'
let handler = async(m, { conn, usedPrefix, command }) => {
await m.reply(`*_Tunggu Sebentar..._*`)
    let url = await fetch('https://raw.githubusercontent.com/heryadin/Api/main/asupan/loli.json')
    let res = await url.json()
    let hasil = res[Math.floor(Math.random() * res.length)]
    conn.sendButton(m.chat, command, wm, hasil, [['NEXT', '.asupanloli']], m)
  }
  handler.command = /^(asupanloli)$/i
  handler.tags = ['asupan']
  handler.help = ['asupanloli']
  handler.premium = true
  export default handler