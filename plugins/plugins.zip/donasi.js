import fetch from 'node-fetch'

//Plugin By Xynoz!!
let handler = async (m, { conn, usedPrefix }) => {
  const ultah = new Date('November 4 2022 00:00:01')
    const sekarat = new Date().getTime() 
    const Kurang = ultah - sekarat
    const ohari = Math.floor( Kurang / (1000 * 60 * 60 * 24));
    const ojam = Math.floor( Kurang % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
    const onet = Math.floor( Kurang % (1000 * 60 * 60) / (1000 * 60))
    const detek = Math.floor( Kurang % (1000 * 60) / 1000)
  let vn = `https://github.com/heryadin/Api/blob/main/mp3/onichan.mp3?raw=true`
  conn.sendButton(m.chat, `  
       ❲ *Donasi* ❳
• Gopay  [082279601471]
• Dana  [082279601471]
• Saweria  [https://saweria.co/hariyadin]

*Note:*
Ingin donasi? Wa.me/682279601471
• Hasil donasi akan digunakan buat sewa_
• atau beli *RDP/VPS* agar bot bisa jalan_
24jam tanpa kendala_
`.trim(), wm, [['Owner',`/owner`]],m) // Tambah sendiri kalo mau
conn.sendFile(m.chat, vn, 'annabot.mp3', null, m, true, {
type: 'audioMessage', 
ptt: true, contextInfo:{ externalAdReply: { title: `Donasi Seikhlasnya Nya Kak🤭`, body: `Join Group Bestie`, sourceUrl: sgc, thumbnail: await (await fetch('https://telegra.ph/file/7da8b18baa6750120c060.jpg')).buffer(),}} 
     }) 
}
handler.command = /^(donasi|dns)$/i
handler.tags = ['info']
handler.help = ['donasi']
handler.premium = false
handler.limit = false

export default handler



