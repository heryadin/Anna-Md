import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
let res = await fetch('https://raw.githubusercontent.com/heryadin/Api/main/random/cecan.json')
if (!res.ok) throw await `${res.status} ${res.statusText}`;
let json = await res.json();
let url = json[Math.floor(Math.random() * json.length)]
conn.sendButton(m.chat, 'Nehhh Kak><\nsumber:  pinterest', wm, url, [['NEXT','.cecan']],m)
}
handler.command = /^(cecan|cewekcantik)$/i
handler.tags = ['random']
handler.help = ['cecan']
handler.limit = true
export default handler