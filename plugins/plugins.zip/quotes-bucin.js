import fetch from 'node-fetch' 
import axios from 'axios'
let handler = async(m, { conn, usedPrefix, text, command }) => {
  let faketr0l = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'},
    message: {
    orderMessage: {
    itemCount : 999999,
    status: 404,
    surface : 404,
    message: `QUOTES BUCIN`,
    orderTitle: `QUOTES BUCIN`,
    thumbnail:   await (await fetch(`https://telegra.ph/file/513de7ed4d919567155a2.jpg`)).buffer(),
    sellerJid: '0@s.whatsapp.net' }}}
	let url = await fetch('https://raw.githubusercontent.com/heryadin/Api/main/quotes/bucin.json')
    let res = await url.json()
    let hasil = res[Math.floor(Math.random() * res.length)]

    conn.sendButton(m.chat, hasil, wm, [[`BUCIN`, `${usedPrefix+command}`]], faketr0l)
}

handler.help = ['bucin']
handler.tags = ['quotes']
handler.command = /^(bucin)$/i
export default handler