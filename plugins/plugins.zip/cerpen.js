import axios from 'axios'
let handler = async(m, { conn, text }) => {

  await m.reply('Searching...')
	let url = await fetch('https://raw.githubusercontent.com/heryadin/Api/main/random/cerpen.json')
    let res = await url.json()
    let hasil = res[Math.floor(Math.random() * res.length)]

    conn.reply(m.chat, hasil, m)
	}

handler.help = ['cerpen']
handler.tags = ['fun']
handler.command = /^(cerpen)$/i

handler.fail = null
handler.exp = 0
handler.limit = true

export default handler
