import fetch from 'node-fetch'
let handler = async(m, { conn, usedPrefix, command }) => {
await m.reply(`*_Tunggu Sebentar..._*`)
  let res = await fetch('https://raw.githubusercontent.com/heryadin/Api/main/asupan/bocil.json')
  let asup = await res.json()
  let hasil = asup[Math.floor(Math.random() * asup.length)]
  conn.sendButton(m.chat, command, wm, hasil.url, [['NEXT','.bocil']], m)
}
handler.help = ['bocil']
handler.tags = ['asupan']
handler.premium = true
handler.command = /^(bocil|asupanbocil)$/i

export default handler
