
 
import fetch from 'node-fetch'
import fs from 'fs'
import moment from 'moment-timezone'
let handler = async (m, { conn, args, command }) => {
  let _uptime = process.uptime() * 1000
let uptime = clockString(_uptime)
let who = m.sender
const time = moment.tz('Asia/Jakarta').format('HH')
  
  let name = await conn.getName(m.sender)
  let runnya = `┏━━━ꕥ〔 Anime 〕ꕥ━⬣
┃✾ .anna 🅛
┃✾ .asuna 🅛
┃✾ .cosplay 🅛
┃✾ .film<film>
┃✾ .animeinfo <anime>
┃✾ .jahy  🅟
┃✾ .animelink 🅛
┃✾ .loli 🅛
┃✾ .mangainfo <judul>
┃✾ .simpown 🅛
┗━━━━━━━━━ꕥ`
  let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
 await conn.sendButton(m.chat, `${wish()} ${name}`,runnya + '\n\n' + wm + '\n\n' + botdate, thumb, [['OWNER','.owner']], m, {
  'document':{'url':'https://telegra.ph/file/7da8b18baa6750120c060.jpg'},
'mimetype':global.dpdf,
'fileName':'「 ANNA BOTZ 」',
'fileLength':fsizedoc,
'pageCount':fpagedoc,
'previewType':'pdf',
contextInfo: { externalAdReply :{ showAdAttribution: true,
                        sourceUrl: syt,
                        mediaType: 2,
                        description: syt,
                        title: namebot,
                        body: namebot,          previewType: 0,
                        thumbnail: await (await fetch(thumb)).buffer(),
                        mediaUrl: syt
                        
                      }}
})
 let vn = `https://github.com/heryadin/Api/blob/main/mp3/onichan.mp3?raw=true`
  conn.sendFile(m.chat, vn, 'anna.cans', null, m, true, {
type: 'audioMessage',
ptt: true })
}


handler.help = ['anime']
handler.command = /^(anime)$/i

handler.limit = false
handler.register = true
handler.exp = 3

export default handler

function wish() {
    let wishloc = ''
  const time = moment.tz('Asia/Jakarta').format('HH')
  wishloc = ('Hi')
  if (time >= 0) {
    wishloc = ('Selamat Malam🌃')
  }
  if (time >= 4) {
    wishloc = ('Selamat Pagi🌄')
  }
  if (time >= 12) {
    wishloc = ('Selamat Siang☀️')
  }
  if (time >= 16) {
    wishloc = ('️ Selamat Malam🌇')
  }
  if (time >= 23) {
    wishloc = ('Selamat Malam🌙')
  }
  return wishloc
}

function clockString(ms) {
    let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
    let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}
