let handler  = async (m, { conn }) => {
  let url = await fetch('https://raw.githubusercontent.com/heryadin/Api/main/game/taugasih.json')
    let res = await url.json()
    let hasil = res[Math.floor(Math.random() * res.length)]

    conn.reply(m.chat, hasil, m)
	}
handler.help = ['taugasih']
handler.tags = ['fun']
handler.command = /^(taugasih)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false
handler.limit = true
handler.admin = false
handler.botAdmin = false

handler.fail = null

export default handler 
