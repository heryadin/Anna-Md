import fetch from 'node-fetch' 
import axios from 'axios'
let handler = async(m, { conn, usedPrefix, text, command, args}) => {
  let faketr0l = {
    key : {
    remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'},
    message: {
    orderMessage: {
    itemCount : 999999,
    status: 404,
    surface : 404,
    message: `SEWA BOTZ`,
    orderTitle: `SEWA BOT`,
    thumbnail:   await (await fetch(`https://telegra.ph/file/513de7ed4d919567155a2.jpg`)).buffer(),
    sellerJid: '0@s.whatsapp.net' }}}
let url = 'https://telegra.ph/file/6ab4daac226292a112540.jpg'
let text = `━━ꕥ〔 *𝚂𝙴𝚆𝙰 & 𝙿𝚁𝙴𝙼𝙸𝚄𝙼* 〕ꕥ━⬣

┏━ꕥ〔 𝚂𝙴𝚆𝙰 〕
┃
┃✾ 30 ʜᴀʀɪ 10ᴋ / ɢʀᴏᴜᴘ
┃✾ 60 ʜᴀʀɪ 15ᴋ / ɢʀᴏᴜᴘ
┃✾ ᴘᴇʀᴍᴀɴᴇɴ 20ᴋ 
┃
┗━━ꕥ *${author}* ꕥ━⬣

┏━ꕥ〔 𝙿𝚁𝙴𝙼𝙸𝚄𝙼 〕
┃
┃✾ 15 ʜᴀʀɪ 10ᴋ 
┃✾ 60 ʜᴀʀɪ 15ᴋ 
┃✾ ᴘᴇʀᴍᴀɴᴇɴ 30ᴋ
┃
┗━━ꕥ *${author}* ꕥ━⬣

┏━ꕥ〔 P R O M O 〕
┃✾ Premium + Sewa 40k / Permanen
┗━━ꕥ *${author}* ꕥ━⬣

┏━ꕥ〔 ꜰɪᴛᴜʀ 450+ 〕
┃
┃✾ ᴡᴇʟᴄᴏᴍᴇ
┃✾ ᴋɪᴄᴋ
┃✾ ᴀɴᴛɪʟɪɴᴋ
┃✾ ꜱᴛɪᴋᴇʀ
┃✾ ꜱᴏᴜɴᴅ
┃✾ ᴀɴɪᴍᴇ
┃✾ ꜱᴇɴᴅ ᴠɪʀᴛᴇx
┃✾ ꜱᴇɴᴅ ʙᴜɢ
┃✾ ɢᴀᴍᴇ ʀᴘɢ
┃✾ ᴅʟʟ
┃
┗━━ꕥ *${author}* ꕥ━⬣
`
conn.sendMessage(m.chat, text, faketr0l)
}
handler.command = /^(masuk)$/i

export default handler
